import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddGrantToVisitor1729509685032 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        -- Grant permissions on the public schema
        GRANT USAGE, CREATE ON SCHEMA public TO postgres_visitor;
        
        -- Grant privileges on existing tables, sequences, and functions
        GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres_visitor;
        GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres_visitor;
        GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO postgres_visitor;
        
        -- Set default privileges for future objects
        ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO postgres_visitor;
        ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO postgres_visitor;
        
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        -- Revoke privileges from the public schema
        REVOKE USAGE, CREATE ON SCHEMA public FROM postgres_visitor;
        
        -- Revoke privileges from existing tables, sequences, and functions
        REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM postgres_visitor;
        REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public FROM postgres_visitor;
        REVOKE ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public FROM postgres_visitor;
        

    `);
  }
}
