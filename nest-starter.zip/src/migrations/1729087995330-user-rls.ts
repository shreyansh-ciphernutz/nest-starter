import { MigrationInterface, QueryRunner } from 'typeorm';

export class UserRls1729087995330 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE public.user ENABLE ROW LEVEL SECURITY;

            CREATE POLICY user_select ON public.user
            USING (current_user_id() IS NOT NULL AND (id = current_user_id()));

        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        DROP POLICY IF EXISTS user_select ON public.user cascade;
        
        ALTER TABLE public.user DISABLE ROW LEVEL SECURITY;
    `);
  }
}
