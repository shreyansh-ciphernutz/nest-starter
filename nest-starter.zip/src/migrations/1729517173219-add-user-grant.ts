import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddUserGrant1729517173219 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
            GRANT SELECT ON public.user TO postgres_visitor;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
            REVOKE SELECT ON public.user FROM postgres_visitor;
        `);
  }
}
