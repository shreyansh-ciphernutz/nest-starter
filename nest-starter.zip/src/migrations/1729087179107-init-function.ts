import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitFunction1729087179107 implements MigrationInterface {
  name = 'InitFunction1729087179107';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        CREATE
            FUNCTION current_session_id() RETURNS uuid AS $$ SELECT
            NULLIF(
                current_setting(
                'jwt.session_id',
                false
                ),
                ''
            )::uuid $$ LANGUAGE SQL SECURITY DEFINER;


            create function current_user_id() returns uuid as $$
            select user_id from session where id = current_session_id();
            $$ language sql stable security definer;
      `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        DROP function if exists current_user_id cascade;
        DROP function if exists current_session_id cascade;
    `);
  }
}
